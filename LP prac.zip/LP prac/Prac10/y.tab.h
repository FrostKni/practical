#ifndef _yy_defines_h_
#define _yy_defines_h_

#define num 257
#define id 258
#define op 259
#define equal 260
#define par 261

#endif /* _yy_defines_h_ */
