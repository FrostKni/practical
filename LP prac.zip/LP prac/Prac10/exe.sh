yacc -d Prac10.y
lex Prac10.l
cc lex.yy.c y.tab.c
./a.out 
