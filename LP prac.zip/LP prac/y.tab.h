#ifndef _yy_defines_h_
#define _yy_defines_h_

#define A 257
#define B 258
#define NEWLINE 259

#endif /* _yy_defines_h_ */
